const ComidaController = require('./ComidaController');

module.exports =(app) =>{
app.post('/comida',ComidaController.post);
app.put('/comida/:id',ComidaController.put);
app.delete('/comida/:id',ComidaController.delete);
app.get('/comida',ComidaController.get);
app.get('/comida/:id',ComidaController.put);

}