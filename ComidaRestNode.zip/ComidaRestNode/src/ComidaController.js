exports.post = async (req, res) =>{
    const conn = await connect();
    const sql = 'INSERT INTO comida(nome,kcal,peso,tipo) VALUES(?,?,?,?);';
    const values = [req.body.nome, req.body.kcal, req.body.peso, req.body.tipo];
    await conn.query(sql, values);
    res.status(201).send('ok!');
   
  };
  
  exports.put = async (req, res, next)  => {
    let id = req.params.id;
    const conn = await connect();
    const sql = 'UPDATE comida SET nome=?, kcal=?, peso=?, tipo=?  WHERE idcomida= ?;';
    const values = [req.body.nome, req.body.kcal, req.body.peso, req.body.tipo, id];
    await conn.query(sql, values);
  
    res.status(201).send('ok');
  };
  exports.delete = async (req, res, next) => {
    let id = req.params.id;
    const conn = await connect();
    const sql = 'DELETE FROM comida WHERE idcomida= ?;';
    const values = [id];
    await conn.query(sql, values);
  
    res.status(200).send('ok');
  };
  
  exports.get = async (req, res, next)  => {
        const conn = await connect();
        const [rows] = await conn.query('SELECT * From comida');
      res.status(200).send(rows);
  };
  
  exports.getById = async (req, res, next) => {
      const conn = await connect();
      const [rows] = await conn.query('SELECT * FROM comida WHERE idcomida = ' + req.params.id);
  
      if (rows.length > 0) {
        res.status(200).send(rows[0]);
      } else {
        res.status(404).send("ID não existe");
      }
   };
  
  
  
  async function connect(){
      if (global.connection && global.connection.state !== 'disconnected') 
          return global.connection;
  
          const mysql = require("mysql2/promise");
          const connection = await
          mysql.createConnection({host: 'localhost', user: 'root', password: '1807', database: 'comidarest'});
  
      console.log("Conectou no MySQL!");
      global.connection = connection;
      return connection;
  }