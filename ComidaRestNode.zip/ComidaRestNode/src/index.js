const ComidaRoute = require('./ComidaRoute');

module.exports = (app) =>{
    ComidaRoute(app)
}