//const { header } = require("express/lib/request");

listar();
var idcomida = 0;
var myModal = new bootstrap.Modal(
  document.getElementById('cadastro')
);

function listar(){
  var requestOptions = {
    method: 'GET',
    redirect: 'follow'
  };

  fetch("http://localhost:3333/comida", requestOptions)
    .then(response => response.json())
    .then(function(result){
      var dados = "<th>nome</th>";
          dados += "<th>kcal</th>";
          dados += "<th>peso</th>";
          dados += "<th>tipo</th>";


      for (const i in result) {
        dados += "<tr>"
            + "<td>" + result[i].nome + "</td>"
            + "<td>" + result[i].kcal + "</td>"
            + "<td>" + result[i].peso + "</td>"
            + "<td>" + result[i].tipo + "</td>"
            + "<td><a class='btn btn-primary' onclick='alterar(" + result[i].idcomida + ")'>Alterar</a></td>"
            + "<td><a class='btn btn-danger' onclick='excluir(" + result[i].idcomida + ")'>Excluir</a></td>"
            + "</tr>";

      }
      document.getElementById("dados").innerHTML = dados;
    })
    .catch(error => console.log('error', error));
}

function alterar(id){
  idcomida = id;
  myModal.show();
  var requestOptions = {
    method: 'GET',
    body: raw,
    redirect: 'follow',
    headers: {
      'Accept' : 'application/json',
      'Content-Type':'application/json',
    },

  };
   
  fetch("http://localhost:3333/comida/" + idcomida, requestOptions)
    .then(response => response.json())
    .then(function(result){
      document.getElementById("nome").value = result.nome;
      document.getElementById("kcal").value = result.kcal;
      document.getElementById("peso").value = result.peso;
      document.getElementById("tipo").value = result.tipo;
      //myModal.show();
    })
    .catch(error => console.log('error', error));
}

function excluir(idcomida){
  var raw = "";
 
  var requestOptions = {
    method: 'DELETE',
    body: raw,
    redirect: 'follow',
    headers: {
      'Accept' : 'application/json',
      'Content-Type':'application/json',
    },

  };
  fetch("http://localhost:3333/comida/" + idcomida, requestOptions)
  .then(response => response.text())
  .then(function(result){
    listar();
  })
  .catch(error => console.log('error', error));
}

function novo(){
  myModal.show();
  idevento=0;
  document.getElementById("nome").value = "";
  document.getElementById("kcal").value = "";
  document.getElementById("peso").value = "";
  document.getElementById("tipo").value = "";
}

function salvar(){
  var metodo;
  if (idcomida > 0 )  {
    metodo = "PUT";
  }else{
    metodo = "POST";
  }

  var p = {};
  p.idcomida = idcomida;
  p.nome = document.getElementById("nome").value;
  p.kcal = document.getElementById("kcal").value;
  p.peso = document.getElementById("peso").value;
  p.tipo = document.getElementById("tipo").value;

  var raw = JSON.stringify(p);
  console.log(raw);
  if ((p.nome == "") || (p.kcal == "") || (p.peso == "")|| (p.tipo == "")){
    alert("nome é obrigatório");
    return;
  }

  var requestOptions = {
    method: metodo,
    body: raw,
    redirect: 'follow',
    headers: {
      'Accept' : 'application/json',
      'Content-Type':'application/json',
    },
  };
 

    var url ;
    if(idevento == 0 ){
      url ="http://localhost:3333/comida";

    }else{
      url = "http://localhost:3333/comida/"+idcomida
    }

  fetch(url, requestOptions)
    .then(response => response.text())
    .then(function (result){
      listar();
    })
    .catch(error => console.log('error', error));

    myModal.hide();
  }